from django.shortcuts import render
from .forms import RegForm, RegModelForm
from .models import Registrado
from django.core.mail import send_mail
from django.conf import settings


# Create your views here.

def inicio(request):
	titulo ="Bienvenido Invitado"
	if request.user.is_authenticated():
		titulo = "bienvenido %s" %(request.user)

	form = RegModelForm(request.POST or None)
	context = {
		"formulario":form,
		"titulo": titulo
	}
	
	if form.is_valid():
		# form_data =  form.cleaned_data
		# name = form_data.get("nombre")
		# email = form_data.get("email")
		# savef = Registrado.objects.create(email=email,nombre=name)
		instance = form.save(commit=False)
		if not instance.nombre:
			instance.nombre = "Persona"
		instance.save()

		send_mail(
			'Subject here',
			'Here is the message.',
			'from@example.com',
			['to@example.com'],
			fail_silently=False,
		)

		context = {
			"titulo": "Gracias por registrarte"
		}
		print instance
	
	return render(request, "base.html",context)
