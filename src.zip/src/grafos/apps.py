from django.apps import AppConfig


class GrafosConfig(AppConfig):
    name = 'grafos'
