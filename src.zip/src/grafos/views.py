from django.shortcuts import render
from neo4j import GraphDatabase
import json

# Create your views here.
def inicio(request):
	context= "devops"
	uri = "bolt://10.63.32.24:7688"
	driver = GraphDatabase.driver(uri, auth=("neo4j", "Pr1v4t3-K3y"))
	objjson= {"comment": "Charlize Therons ego network as GraphJSON","nodes": [{"caption": "Screen Actors Guild Award for Outstanding Performance by a Female Actor in a Miniseries or Television Movie","type": "award","id": 595472},{"caption": "Children of the Corn III: Urban Harvest","type": "movie","id": 626470},{"caption": "Stuart Townsend","type": "person","id": 314004}],"edges": [{"source": 595472,"target": 626470,"caption": "ACTED_IN"},{"source": 626470,"target": 314004,"caption": "ACTED_IN"},{"source": 314004,"target": 626470,"caption": "NOMINATED"}]}
	record2 =''
	def print_friends_of(tx, name):
		st = ""
		allInfo = []
		xx=tx.run("match (n) return n, collect(n)")
		print(xx.single()[0])
		for data in tx.run("match (n) return n, collect(n)"):
			print(data["n"]);
			st += str(data["n"])
		data = {}
		data['nodes'] = 'value'
		data['relationships'] = 'value'
		
		dataj =  '{ "name":"John", "age":30, "city":"New York"}'
		# jsonobj = {"nodes": {}, "relationships": {}}
		# jsonobj["nodes"].append({"f":var3, "g":var4, "h":var5})
		q =	{} #dict
		w = [] #list
		x = [] #list

		for record in tx.run("MATCH (res:OT)-[x:_]->(r) RETURN properties(r), type(x), labels(res), labels(r), id(res),r,res,properties(res),x, properties(x)"):
			print("###########################################")
			thisdict =	{"id": str(record['r'].id),"labels":record['labels(r)'],"properties":{"from": "prueba"}}
			# print(thisdict)
			w.append(thisdict)
			# q['nodes']+=thisdict
			print(record['r'])
			print(record['r'].id)
			print(record['labels(r)'])
			print(record['properties(r)'])
			print("&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&")
			print(record['res'])
			print(record['res'].id)
			print(record['labels(res)'])
			print(record['properties(res)'])
			thisdict =	{"id": str(record['res'].id),"labels":record['labels(res)'],"properties":{"from": "algo raro"}}
			# print(thisdict)
			w.append(thisdict)
			print("(((((((((((((((((((((((((((((((((((((((")
			print(record['type(x)'])
			print(record['x'].id)
			print(record['x'].nodes[0].id)
			print(record['x'].nodes[1].id)
			print(record['properties(x)'])
			thisdict2 =	{"id": str(record['x'].id),"type":record['type(x)'],"startNode":str(record['x'].nodes[0].id),"endNode":str(record['x'].nodes[1].id),"properties":{"from": "1470002400000"}}
			# print(thisdict)
			x.append(thisdict2)

			# print(record['x'].properties)

			# allInfo.append({'start': {'id': record['a'].id}})
		q['nodes']=w
		q['relationships']=x
		json_data = json.dumps(q)
		with open('data.json', 'w') as outfile:  
			json.dump(q, outfile)
		print(json_data)

		return st


	with driver.session() as session:
		record = session.read_transaction(print_friends_of, "Alice")

	# b = json.loads(json)
	b = json.dumps(objjson)
	# for record in tx.run("match (n) return n"):
	# 	print(record["n"]);
	context = {
		"context": context,
		"record": record2,
		"json": b,
	}
	return render(request,"base.html",context)

def grafos(request):
	context= "devops"
	uri = "bolt://10.63.32.24:7688"
	driver = GraphDatabase.driver(uri, auth=("neo4j", "Pr1v4t3-K3y"))
	objjson= {"comment": "Charlize Therons ego network as GraphJSON","nodes": [{"caption": "Screen Actors Guild Award for Outstanding Performance by a Female Actor in a Miniseries or Television Movie","type": "award","id": 595472},{"caption": "Children of the Corn III: Urban Harvest","type": "movie","id": 626470},{"caption": "Stuart Townsend","type": "person","id": 314004}],"edges": [{"source": 595472,"target": 626470,"caption": "ACTED_IN"},{"source": 626470,"target": 314004,"caption": "ACTED_IN"},{"source": 314004,"target": 626470,"caption": "NOMINATED"}]}
	record2 =''
	def print_friends_of(tx, name):
		st = ""
		allInfo = []
		xx=tx.run("match (n) return n, collect(n)")
		print(xx.single()[0])
		for data in tx.run("match (n) return n, collect(n)"):
			print(data["n"]);
			st += str(data["n"])
		data = {}
		data['nodes'] = 'value'
		data['relationships'] = 'value'
		
		dataj =  '{ "name":"John", "age":30, "city":"New York"}'
		# jsonobj = {"nodes": {}, "relationships": {}}
		# jsonobj["nodes"].append({"f":var3, "g":var4, "h":var5})
		q =	{} #dict
		w = [] #list
		x = [] #list

		for record in tx.run("MATCH (res:OT)-[x:_]->(r) RETURN properties(r), type(x), labels(res), labels(r), id(res),r,res,properties(res),x, properties(x) LIMIT 50"):
			print("###########################################")
			thisdict =	{"id": str(record['r'].id),"labels":record['labels(r)'], "Properties" : record['properties(r)']}
			# print(thisdict)
			w.append(thisdict)
			# q['nodes']+=thisdict
			print(record['r'])
			print(record['r'].id)
			print(record['labels(r)'])
			print(record['properties(r)'])
			print("&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&")
			print(record['res'])
			print(record['res'].id)
			print(record['labels(res)'])
			print(record['properties(res)'])
			thisdict =	{"id": str(record['res'].id),"labels":record['labels(res)'],"properties":{"from": "algo raro"}}
			# print(thisdict)
			w.append(thisdict)
			print("(((((((((((((((((((((((((((((((((((((((")
			print(record['type(x)'])
			print(record['x'].id)
			print(record['x'].nodes[0].id)
			print(record['x'].nodes[1].id)
			print(record['properties(x)'])
			thisdict2 =	{"id": str(record['x'].id),"type":record['type(x)'],"startNode":str(record['x'].nodes[0].id),"endNode":str(record['x'].nodes[1].id),"properties":{"from": "1470002400000"}}
			# print(thisdict)
			x.append(thisdict2)

			# print(record['x'].properties)

			# allInfo.append({'start': {'id': record['a'].id}})
		q['nodes']=w
		q['relationships']=x
		aa = "{'results': [{'columns': ['user', 'entity'],'data': [{'graph':"+str(q)+"}]}],'errors': []}"
		json_data = json.dumps(aa)
		with open('data2.json', 'w') as outfile:  
			json.dump(aa, outfile)
		print(json_data)

		return st


	with driver.session() as session:
		record = session.read_transaction(print_friends_of, "Alice")

	# b = json.loads(json)
	b = json.dumps(objjson)
	# for record in tx.run("match (n) return n"):
	# 	print(record["n"]);
	context = {
		"context": context,
		"record": record2,
		"json": b,
	}
	
	return render(request, 'template.html')