var totalInfo = "";

function selectNode(node) {
	var svg = d3.select("svg");
	
	var nodeClass = $(node).attr("class").split(" ");
	var node = nodeClass[nodeClass.length - 1];
	
	var nodes = svg.select("." + node)
		.attr("fill", "red");
	
	console.log(nodeClass);
	console.log(node);
}

function findNode(row, nodos) {
	var exist = false;
	if(nodos != null && nodos.length > 0 && row.NOMBRE != null) {
		nodos.forEach(function (nodo) {
			if(nodo.NOMBRE === row.NOMBRE) {
				exist = true;
			}
		});
	}
	
	return exist;
}

function graph(data) {
    var graph = getD3Data(JSON.parse(data.qry))
    update(graph.links, graph.nodes);
    
}

function update(links, nodes) {
    $("#graphArea").empty();
    $("#properties").empty();
    var colors = d3.scaleOrdinal(d3.schemeCategory10);
    var contGrupo = 0;
    var contStkHolder = 0;
    var contCelula = 0;
    var contRequerimiento = 0;
    var contResponsableTI = 0;
    var contOtros = 0;
    
    
	
    var svg = d3.select("#graphArea").append("svg")
                .attr("id", "svgArea")
			    .attr("width", "100%").attr("height", "100%")
			    .attr("pointer-events", "all")
                .attr("class", "view");

    var width = +svg.node().getBoundingClientRect().width,
    	height = +svg.node().getBoundingClientRect().height,
        node,
        link;
    
	var zoom = d3.zoom()
	    .scaleExtent([0, 1])
	    .on("zoom", zoomed);
	
    svg.append('defs').append('marker')
        /*.attrs({'id':'arrowhead',
            'viewBox':'-0 -5 10 10',
            'refX':13,
            'refY':0,
            'orient':'auto',
            'markerWidth':13,
            'markerHeight':13,
            'xoverflow':'visible'})*/
        .attr('id', 'arrowhead')
        .attr('viewBox', '-0 -5 10 10')
        .attr('refX', 42)
        .attr('refY', 0)
        .attr('orient', 'auto')
        .attr('markerWidth', 13)
        .attr('markerHeight', 13)
        .attr('xoverflow', 'visible')
        .attr("orient", "auto-start-reverse")
        .append('svg:path')
        .attr('d', 'M 0,-5 L 10 ,0 L 0,5')
        .attr('fill', '#999')
        .style('stroke','none');

    var simulation = d3.forceSimulation()
    	.force("link", d3.forceLink().distance(230).strength(0.2))
        .force("collide",d3.forceCollide( function(d){return d.r + 8 }).iterations(16) )
        .force("charge", d3.forceManyBody().strength(-800))
        .force("y", d3.forceY(height / 2))
        .force("x", d3.forceX(width / 2));
        
    var rec = svg.append("rect")
    				.attr("x", "-2500")
    				.attr("y", "-2500")
    				.attr("width", "5000")
    				.attr("height", "5000")
    				.attr("style", "fill: none; pointer-events: all;")
    				.attr("transform", "scale(1)")
    				.call(zoom);
    
    var layer2 = svg.append("g");
    
    function zoomed() {
    	var transform = d3.event.transform;
    	layer2.attr('transform', 'translate(' + transform.x + ', ' + transform.y + ') scale(' + transform.k + ')');
    	
	}
    
    var layerLinks = layer2.append("g")
							.attr("class", "layer relationships");
    
    var layerNodes = layer2.append("g")
						.attr("class", "layer nodes");
    
    link = layerLinks.selectAll(".link")
        .data(links)
        .enter()
        .append("line")
        .attr("class", "link")
        .attr('marker-start','url(#arrowhead)')

    link.append("title")
        .text(function (d) {
        	return d.type;
        });

    edgepaths = layerLinks.selectAll(".edgepath")
        .data(links)
        .enter()
        .append('path')
        /*.attrs({
            'class': 'edgepath',
            'fill-opacity': 0,
            'stroke-opacity': 0,
            'id': function (d, i) {
            	return 'edgepath' + i
            }
        })*/
        .attr('class','edgepath')
        .attr('fill-opacity',0)
        .attr('stroke-opacity',0)
        .attr('id',function (d, i) {
            return 'edgepath' + i
        })
        .style("pointer-events", "none");

    edgelabels = layerLinks.selectAll(".edgelabel")
        .data(links)
        .enter()
        .append('text')
        .style("pointer-events", "none")
        /*
        .attrs({
            'class': 'edgelabel',
            'id': function (d, i) {return 'edgelabel' + i},
            'font-size': 10,
            'fill': '#aaa'
        })*/
        .attr('class','edgelabel')
        .attr('font-size',10)
        .attr('fill',0)
        .attr('id',function (d, i) {
            return 'edgelabel' + i
        });

    edgelabels.append('textPath')
        .attr('xlink:href', function (d, i) {return '#edgepath' + i})
        .style("text-anchor", "middle")
        .style("pointer-events", "none")
        .attr("startOffset", "50%")
        .text(function (d) {return d.type});

    node = layerNodes.selectAll(".node")
        .data(nodes)
        .enter()
        .append("g")
        .attr("class", "node")
        .call(d3.drag()
                .on("start", dragstarted)
                .on("drag", dragged)
//                .on("end", dragended)
        )
        .on("click", showProperties)
        .on("mousemove", showProperties)
        .on("mouseout", cleanProperties);

    node.append("circle")
	    .attr("r", 46)
	    .attr("stroke-width", "8px")
	    .attr("class", "ring");
    
    node.append("circle")
        .attr("r", 42)
        .attr("stroke-width", "2px")
        .attr("stroke", function (d, i) {
            switch (d.TIPONODO) {
                case 'GRUPO':
                    contGrupo++
                    return '#60B58B';
                case 'STAKEHOLDER':
                    contStkHolder++;
                    return '#5CA8DB';
                case 'CELULA':
                    contCelula++;
                    return '#FF4848';
                case 'REQUERIMIENTO':
                    contRequerimiento++;
                    return '#BF85D6';
                case 'RESPONSABLETI':
                    contResponsableTI++;
                    return '#2966B8';
                default:
                    contOtros++;
                    return '9AA1AC';
            }
        })
        .style("fill", function (d, i) {
            switch (d.TIPONODO) {
                case 'GRUPO':
                    return '#6DCE9E';
                case 'STAKEHOLDER':
                    return '#68BDF6';
                case 'CELULA':
                    return '#FF7575';
                case 'REQUERIMIENTO':
                    return '#DE9BF9';
                case 'RESPONSABLETI':
                    return '#2F74D0';
                default:
                    return '#A5ABB6';
            }
        });

    showCountNodes(contGrupo, contStkHolder, contCelula, contRequerimiento, 
        contResponsableTI, contOtros);

    totalInfo = "<span>" + nodes.length + " NODOS y " + links.length + " RELACIONES </span>";

    $("#properties").html(totalInfo);

    node.append("title")
        .text(function (d) {
        	return d.NOMBRE;
        });

    node.append("text")
    	.attr("fill", "#FFFFFF")
		.attr("text-anchor", "middle")
		.attr("style", "font-family: sans-serif")
        .attr("font-size", 9)
        .attr("class", "font-bold")
        .text(function(d) { return d.NOMBRE; });

    node.selectAll("text")
        .call(wrap);

    simulation
        .nodes(nodes)
        .on("tick", ticked);

    simulation.force("link")
        .links(links);
    
    function ticked() {
        link
            .attr("x1", function (d) {return d.source.x;})
            .attr("y1", function (d) {return d.source.y;})
            .attr("x2", function (d) {return d.target.x;})
            .attr("y2", function (d) {return d.target.y;});

        node
            .attr("transform", function (d) {return "translate(" + d.x + ", " + d.y + ")";});

        edgepaths.attr('d', function (d) {
            return 'M ' + d.source.x + ' ' + d.source.y + ' L ' + d.target.x + ' ' + d.target.y;
        });

        edgelabels.attr('transform', function (d) {
            if (d.target.x < d.source.x) {
                var bbox = this.getBBox();

                rx = bbox.x + bbox.width / 2;
                ry = bbox.y + bbox.height / 2;
                return 'rotate(180 ' + rx + ' ' + ry + ')';
            }
            else {
                return 'rotate(0)';
            }
        });
    }

    function dragstarted(d) {
        if (!d3.event.active) simulation.alphaTarget(0.3).restart()
        d.fx = d.x;
        d.fy = d.y;
    }

    function dragged(d) {
        d.fx = d3.event.x;
        d.fy = d3.event.y;
    }
    
    function dragended(d) {
        if (!d3.event.active) simulation.alphaTarget(0);
        d.fx = undefined;
        d.fy = undefined;
    }

    function showProperties(d) {
        var childrens = $(this).children();
        var child = childrens[1];
        $("#properties").empty();
        var properties = "";
        var propertyTipoNodo = "<span id='propertyTipoNodo' class='tipoNodo'" + "style='background-color: " + child.style.fill + "; color: #FFFFFF;' >";
        var propertyNombre = "<span id='propertyNombre'>";
        var otherProperties = "";
        for(var property in d) {
            if(property !== 'x' && property !== 'y' 
                && property !== 'fx' && property !== 'fy' 
                && property !== 'vx' && property !== 'vy' 
                && property !== 'id' && property !== 'index') {
                switch (property) {
                    case 'TIPONODO':
                        propertyTipoNodo = propertyTipoNodo +  d[property] + "</span>&nbsp;&nbsp;";
                        break;
                    case 'NOMBRE':
                        propertyNombre = propertyNombre +  "<span class='font-bold'>" + property + ":</span> " + d[property] + "</span>&nbsp;&nbsp;";
                        break;
                    default:
                        otherProperties = otherProperties + "<span> <span class='font-bold'>" + property + ":</span> " + d[property] + "</span>&nbsp;&nbsp;";
                        break;
                }
            }
        }
        properties = properties + propertyTipoNodo + propertyNombre + otherProperties;
        $("#properties").html(properties);
    }
}

function wrap(text) {
    text.each(function() {
        var text = d3.select(this),
            words = text.text().split(/\s+/),
            y = text.attr("y"),
            tspan = text.text(null).append("tspan");
        
        switch (words.length) {
            case 1:
                words.forEach(function (word, i) {
                    text.append("tspan").attr("x", 0).attr("y", 0).text(word);
                });
                break;
            case 2:
                y = -5;
                words.forEach(function (word, i) {
                    text.append("tspan").attr("x", 0).attr("y", y).text(word);
                    y = y + 15;
                });
                break;
            case 3:
                y = -10;
                words.forEach(function (word, i) {
                    text.append("tspan").attr("x", 0).attr("y", y).text(word);
                    y = y + 15;
                });
                break;
            default:
                y = -15;
                words.forEach(function (word, i) {
                    if(i < 4) {
                        if(i == 3) {
                            if(word.length > 10) {
                                text.append("tspan").attr("x", 0).attr("y", y).text(word.substring(0,9) + "...");
                            } else {
                                text.append("tspan").attr("x", 0).attr("y", y).text(word);
                            }
                        } else {
                            text.append("tspan").attr("x", 0).attr("y", y).text(word);
                            y = y + 15;
                        }
                    }
                });
                break;
        }
    });
  }

function showCountNodes(contGrupo, contStkHolder, contCelula, 
    contRequerimiento, contResponsableTI, contOtros) {
    var info = "";
    if(contGrupo > 0) {
        info = info + "<span class='tipoNodo' style='background-color: #6DCE9E; color: #FFFFFF;'>GRUPO (" + contGrupo + ")</span>&nbsp;&nbsp;"
    }
    if(contStkHolder > 0) {
        info = info + "<span class='tipoNodo' style='background-color: #68BDF6; color: #FFFFFF;'>STAKEHOLDER (" + contStkHolder + ")</span>&nbsp;&nbsp;"
    }
    if(contCelula > 0) {
        info = info + "<span class='tipoNodo' style='background-color: #FF756E; color: #FFFFFF;'>CELULA (" + contCelula + ")</span>&nbsp;&nbsp;"
    }
    if(contRequerimiento > 0) {
        info = info + "<span class='tipoNodo' style='background-color: #DE9BF9; color: #FFFFFF;'>REQUERIMIENTO (" + contRequerimiento + ")</span>&nbsp;&nbsp;"
    }
    if(contResponsableTI > 0) {
        info = info + "<span class='tipoNodo' style='background-color: #2F74D0; color: #FFFFFF;'>RESPONSABLETI (" + contResponsableTI + ")</span>&nbsp;&nbsp;"
    }
    if(contOtros > 0) {
        info = info + "<span class='tipoNodo' style='background-color: #A5ABB6; color: #FFFFFF;'>* (" + contOtros + ")</span>"
    }

    $("#contNodos").html(info);
}

function cleanProperties(d) {
    $("#properties").empty();
    $("#properties").html(totalInfo);
}

function getD3Data(data) {
    var nodos = [];
    var links = [];
    var indexNodes = [];

    data.results.forEach(function (result) {
        result.data.forEach(function (dataRow) {
            dataRow.row.forEach(function (row, i) {
                var exist = false;

                if (dataRow.meta[i] != null) {
                    row.id = dataRow.meta[i].id
                }

                if (nodos != null && nodos.length > 0 && row.NOMBRE != null) {
                    nodos.forEach(function (nodo) {
                        if (nodo.id === row.id) {
                            exist = true;
                        }
                    });
                }

                if (row.NOMBRE != null && exist === false) {
                    indexNodes.push(row.id);
                    nodos.push(row);
                }

                if (i > 0 && (i % 2) === 0) {
                    var existLink = false;
                    if(links != null && links.length > 0) {
                        links.forEach(function (link) {
                            if (link.source === dataRow.meta[i - 2].id && link.target === dataRow.meta[i].id) {
                                existLink = true;
                            }
                        });
                    }
                    
                    if(existLink === false) {
                        links.push({ source: dataRow.meta[i - 2].id, target: dataRow.meta[i].id, type: dataRow.row[i - 1] })
                    }
                }
            });
        });
    });

    links = this.updateLinks(links, indexNodes);

    return { nodes: nodos, links: links };
}

function updateLinks(links, indexNodes) {
    var newLinks = [];
    links.forEach(function (link, i) {
        if (indexNodes.indexOf(link.source) != -1 && indexNodes.indexOf(link.target) != -1) {
            link.source = indexNodes.indexOf(link.source);
            link.target = indexNodes.indexOf(link.target);
            newLinks.push(link);
        }
    });
    return newLinks;
}

function resizeGraphArea(obj) {
    isSafari = /constructor/i.test(window.HTMLElement) || (function (p) { return p.toString() === "[object SafariRemoteNotification]"; })(!window['safari'] || safari.pushNotification);
    var childrens = $(obj).children();
    var iTag = childrens[0];
    if($(iTag).hasClass("ion-arrow-expand")) {
        if(isSafari) {
            $("#graphArea").removeClass("minimize").addClass("maximize-safari");
            $("#containerGraph").addClass("maximize-safari");
        } else {
            $("#graphArea").removeClass("minimize").addClass("maximize");
            $("#containerGraph").addClass("maximize");
        }
        $(".layout-container").css({"padding-top":"0"});
        $(".main-content").css({"padding":"0 0 0"});
        $("#criteriosBusqueda").hide();
        $(".menu-sidebar").hide();
        $(".fixed").hide();
        $("#resizeIcon").removeClass("ion-arrow-expand").addClass("ion-arrow-shrink");
        $(".scrollable-container").removeClass("scrollable-container").addClass("scrollable-container-temp");
    } else if($(iTag).hasClass("ion-arrow-shrink")) {
        if(isSafari) {
            $("#graphArea").removeClass("maximize-safari").addClass("minimize");
            $("#containerGraph").removeClass("maximize-safari");
        } else {
            $("#graphArea").removeClass("maximize").addClass("minimize");
            $("#containerGraph").removeClass("maximize");
        }
        $(".layout-container").css({"padding-top": "4.75rem"});
        $(".main-content").removeAttr("style");
        $("#criteriosBusqueda").show();
        $(".menu-sidebar").show();
        $(".fixed").show();
        $("#resizeIcon").removeClass("ion-arrow-shrink").addClass("ion-arrow-expand");
        $(".scrollable-container-temp").removeClass("scrollable-container-temp").addClass("scrollable-container");
    }
}
